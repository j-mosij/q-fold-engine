import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";

export const Route = createFileRoute("/")({ component: Home });

const W = 12;
const D = 16;
const CHAR_MAP = [".", ",", "-", "~", ":", ";", "=", "+", "*", "x", "#", "%", "@"];

type C = { r: number; i: number };
type Grid = C[][][];

function quantize15(r: number, g: number, b: number): [number, number, number] {
  const q = (v: number) => Math.min(255, Math.floor((v / 255) * 31) * 8);
  return [q(r), q(g), q(b)];
}

const STOPS: [number, number, number][] = [
  [0, 0, 4],
  [24, 12, 60],
  [87, 21, 126],
  [177, 50, 90],
  [241, 135, 56],
  [252, 253, 164],
];

function magma(t: number): [number, number, number] {
  t = Math.max(0, Math.min(1, t));
  const idx = t * (STOPS.length - 1);
  const i = Math.floor(idx);
  const f = idx - i;
  if (i >= STOPS.length - 1) return quantize15(...STOPS[STOPS.length - 1]);
  const a = STOPS[i];
  const b = STOPS[i + 1];
  return quantize15(
    Math.round(a[0] + (b[0] - a[0]) * f),
    Math.round(a[1] + (b[1] - a[1]) * f),
    Math.round(a[2] + (b[2] - a[2]) * f),
  );
}

function seed(): Grid {
  return Array.from({ length: W }, () =>
    Array.from({ length: W }, () =>
      Array.from({ length: D }, () => {
        const r = Math.random() * 2 - 1;
        const i = Math.random() * 2 - 1;
        const n = Math.hypot(r, i) || 1;
        return { r: r / n, i: i / n };
      }),
    ),
  );
}

function step(prev: Grid): Grid {
  return prev.map((row, y) =>
    row.map((col, x) =>
      col.map((voxel, z) => {
        const left = prev[y][(x - 1 + W) % W][z];
        const right = prev[y][(x + 1) % W][z];
        const up = prev[(y - 1 + W) % W][x][z];
        const down = prev[(y + 1) % W][x][z];
        const convR = voxel.r * 0.6 + (left.r + right.r + up.r + down.r) * 0.1;
        const convI = voxel.i * 0.6 + (left.i + right.i + up.i + down.i) * 0.1;
        const phase = (Math.random() - 0.5) * 0.5;
        const cos = Math.cos(phase);
        const sin = Math.sin(phase);
        let newR = convR * cos - convI * sin;
        let newI = convR * sin + convI * cos;
        const n = Math.hypot(newR, newI) || 1;
        return { r: newR / n, i: newI / n };
      }),
    ),
  );
}

function Home() {
  const [grid, setGrid] = useState<Grid | null>(null);
  const [running, setRunning] = useState(false);
  const [slice, setSlice] = useState(0);
  const [logs, setLogs] = useState<string[]>([
    "[SYSTEM] BOOT SEQUENCE INITIATED...",
    "[SECURITY] ENCRYPTION HEADERS INJECTED.",
    "[GEOMETRY] 15-BIT TONAL CONVOLUTION READY.",
  ]);

  const log = useCallback((msg: string) => {
    setLogs((prev) => [...prev.slice(-5), msg]);
  }, []);

  useEffect(() => {
    setGrid(seed());
    log("[ENGINE] SIMULATION MATRIX RESET.");
  }, [log]);

  useEffect(() => {
    if (!running) return;
    const id = window.setInterval(() => setGrid((g) => (g ? step(g) : g)), 100);
    return () => window.clearInterval(id);
  }, [running]);

  return (
    <main className="min-h-screen bg-slate-950 text-slate-300 font-mono p-4 sm:p-6">
      <div className="mx-auto max-w-5xl">
        <header className="flex flex-wrap items-end justify-between gap-4 border-b-2 border-emerald-800/50 pb-4 mb-6">
          <div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tighter text-emerald-400">
              Q-FOLD ENGINE_
            </h1>
            <p className="text-[11px] text-emerald-700 mt-1">
              [SYS_STAT: OPERATIONAL] // [ENC_LVL: MAXIMUM] // [VOXEL: 15-BIT]
            </p>
          </div>
          <div className="text-right text-[11px] text-slate-500">
            <p>LOC: 0x8F9A.44V</p>
            <p className="text-emerald-500 animate-pulse">UPLINK ACTIVE</p>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-5">
          <section className="space-y-4">
            <div className="relative overflow-hidden rounded-lg border border-slate-800 bg-slate-900 p-4">
              <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-emerald-500 to-violet-500" />
              <h2 className="mb-3 text-xs font-bold tracking-widest text-slate-400">COMMAND_UPLINK</h2>
              <button
                type="button"
                onClick={() => {
                  setRunning((r) => !r);
                  log(running ? "[ENGINE] SIMULATION PAUSED." : "[ENGINE] SIMULATION RUNNING...");
                }}
                className={`mb-4 w-full rounded border py-2.5 text-sm font-bold ${
                  running
                    ? "border-red-800/60 bg-red-950/60 text-red-300"
                    : "border-emerald-800/60 bg-emerald-950/60 text-emerald-300"
                }`}
              >
                {running ? "PAUSE" : "EXECUTE"}
              </button>
              <div className="mb-1 flex justify-between text-[11px] text-slate-400">
                <span>W-AXIS FOLD</span>
                <span className="text-emerald-400">Z {slice}</span>
              </div>
              <input
                suppressHydrationWarning
                type="range"
                min={0}
                max={15}
                value={slice}
                onChange={(e) => setSlice(Number(e.target.value))}
                className="w-full"
                aria-label="Fold index"
              />
              <button
                type="button"
                onClick={() => {
                  setGrid(seed());
                  log("[ENGINE] SIMULATION MATRIX RESET.");
                }}
                className="mt-3 w-full rounded border border-slate-700 py-2 text-xs text-slate-300"
              >
                RESET MATRIX
              </button>
            </div>

            <div className="rounded-lg border border-slate-800 bg-black p-4 text-[11px]">
              <h2 className="mb-2 border-b border-slate-800 pb-2 text-slate-500">SECURE_LOG</h2>
              <div className="flex h-32 flex-col justify-end gap-1 overflow-hidden">
                {logs.map((line, i) => (
                  <div key={i} className={i === logs.length - 1 ? "text-emerald-400" : "text-slate-600"}>
                    {"> "}
                    {line}
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-lg border border-slate-800 bg-slate-900 p-4 text-xs">
              <h2 className="mb-2 text-[11px] font-bold tracking-widest text-slate-400">DOWNLOADS</h2>
              <p className="mb-3 text-slate-500">
                Standalone HTML opens offline. Python script is stdlib-only (terminal or local server).
              </p>
              <div className="flex flex-col gap-2">
                <a
                  href="/qfold.html"
                  download="qfold.html"
                  className="rounded border border-emerald-800/60 bg-emerald-950/40 px-3 py-2 text-center text-emerald-300"
                >
                  Download qfold.html
                </a>
                <a
                  href="/qfold.py"
                  download="qfold.py"
                  className="rounded border border-violet-800/60 bg-violet-950/40 px-3 py-2 text-center text-violet-300"
                >
                  Download qfold.py
                </a>
              </div>
            </div>
          </section>

          <section className="flex items-center justify-center overflow-auto rounded-lg border border-slate-800 bg-slate-900 p-3 sm:p-6">
            {!grid ? (
              <p className="text-emerald-400">INITIALIZING TENSOR CORE...</p>
            ) : (
              <div
                className="grid gap-[2px] border-2 border-slate-800 bg-slate-950 p-1"
                style={{ gridTemplateColumns: "repeat(12, minmax(0, 1fr))" }}
              >
                {grid.map((row, y) =>
                  row.map((col, x) => {
                    const v = col[slice];
                    const t = (v.r + 1) / 2;
                    const [r, g, b] = magma(t);
                    const ch = CHAR_MAP[Math.max(0, Math.min(CHAR_MAP.length - 1, Math.floor(t * (CHAR_MAP.length - 1))))];
                    return (
                      <div
                        key={`${y}-${x}`}
                        className="flex h-7 w-7 items-center justify-center text-[10px] font-black sm:h-8 sm:w-8"
                        style={{
                          backgroundColor: `rgb(${r},${g},${b})`,
                          color: t > 0.6 ? "rgba(0,0,0,0.7)" : "rgba(255,255,255,0.75)",
                          boxShadow: "inset 0 0 0 1px rgba(0,0,0,0.25)",
                        }}
                        title={`Re ${v.r.toFixed(3)} Im ${v.i.toFixed(3)}`}
                      >
                        {ch}
                      </div>
                    );
                  }),
                )}
              </div>
            )}
          </section>
        </div>
      </div>
    </main>
  );
}
