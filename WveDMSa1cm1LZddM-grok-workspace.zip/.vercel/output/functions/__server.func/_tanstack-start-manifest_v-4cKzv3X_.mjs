//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-4cKzv3X_.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BuDBn8J5.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BuDBn8J5.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Bxyxycx0.js"]
	}
} });
//#endregion
export { tsrStartManifest };
